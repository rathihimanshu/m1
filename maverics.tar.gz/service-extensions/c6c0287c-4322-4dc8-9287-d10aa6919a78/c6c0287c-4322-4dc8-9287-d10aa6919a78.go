package main

import (
	"net/http"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

func ModifyResponse(api orchestrator.Orchestrator, resp *http.Response) {
	if resp.Request.URL.Path != "/special/path/" {
		return
	}

	api.Logger().Debug("se", "setting status code for '/special/path/' resource")
	resp.StatusCode = http.StatusOK
}