package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// CreateHeader runs on every request and ALWAYS adds the preferredName header.
// – If the user’s names are on the Maverics session, we build a personalised
//   value.
// – If anything goes wrong we fall back to a literal default and still return
//   nil error so the header is injected.
func CreateHeader(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) (http.Header, error) {
	// default value that will be used if anything fails
	h := http.Header{"preferredName": []string{"something"}}

	// try to personalise it
	return h, nil
}
