package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// CreateHeader runs on every request and ALWAYS adds the preferredName header.
// – If the user’s names are on the Maverics session, we build a personalised
//   value.
// – If anything goes wrong we fall back to a literal default and still return
//   nil error so the header is injected.
func CreateHeader(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) (http.Header, error) {
	// default value that will be used if anything fails
	h := http.Header{"preferredName": []string{"something"}}

	// try to personalise it
	session, err := api.Session()
	if err != nil {
		api.Logger().Error("se", "unable to get session", "error", err.Error())
		return h, nil // keep the default header, no error
	}

	first, err1 := session.GetString("azure.givenname")
	last,  err2 := session.GetString("azure.surname")

	// any lookup error or missing data → keep default header
	if err1 != nil || err2 != nil || first == "" || last == "" {
		if err1 != nil {
			api.Logger().Warn("se", "givenname not found", "error", err1.Error())
		}
		if err2 != nil {
			api.Logger().Warn("se", "surname not found", "error", err2.Error())
		}
		return h, nil
	}

	// personalise the value
	h.Set("preferredName", fmt.Sprintf(`%s 'The Great' %s`, first, last))
	return h, nil
}
