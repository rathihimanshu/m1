package main

import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func IsLoggedIn(api orchestrator.Orchestrator, _ http.ResponseWriter, req *http.Request) bool {
	var logger = api.Logger()
	logger.Debug("se", "determining if user has session with upstream app")

	if req.URL.Path == "/login" {
		return true
	}
	
	_, err := req.Cookie(".ASPXAUTH")
	if err != nil {
		logger.Debug("se", "user is not authenticated with upstream app")
		return false
	}

	logger.Debug("se", "user is authenticated with upstream app")
	return true
}

func Login(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	api.Logger().Info("se", "redirecting user to upstream app's login page")
	
	http.Redirect(rw, req, ":5001/login", http.StatusFound)
	return nil
}