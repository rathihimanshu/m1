package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func Serve(api orchestrator.Orchestrator) error {
	var (
		logger = api.Logger()
		router = api.Router()
	)

	logger.Info("se", "exposing custom API")

	_ = router.HandleFunc("/", func(rw http.ResponseWriter, req *http.Request) {
		_, _ = fmt.Fprint(rw, req.URL)
	})

	return nil
}